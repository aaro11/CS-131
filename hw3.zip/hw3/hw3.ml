
(* Load this file in the ocaml interpreter, and the MOCaml
   read-eval-print loop will be started. *)

#use "env.ml";;
#use "ast.ml";;
#use "parser.ml";;
#use "lexer.ml";;
#use "interp.ml";;
#use "repl.ml";;
