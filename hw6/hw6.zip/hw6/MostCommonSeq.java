import java.util.*;

import static java.util.Map.Entry;

public class MostCommonSeq {

    public static void main(String[] args) {
	Mapper<List<String>,Integer,String,List<String>> m =
	    new Mapper<List<String>,Integer,String,List<String>>() {
	    public List<Entry<String,List<String>>>
	    apply(Entry<List<String>,Integer> entry) {
		throw new RuntimeException("MostCommonSeq.Mapper not implemented");
	    }
	};

	Reducer<String,List<String>> r =
	    new Reducer<String,List<String>>() {
	    public List<String>
	    apply(Entry<String,List<List<String>>> entry) {
		throw new RuntimeException("MostCommonSeq.Reducer not implemented");
	    }
	};

	MiniMapReduce<List<String>,Integer,String,List<String>> mr = 
	    new MiniMapReduce<List<String>,Integer,String,List<String>>(m, r);
	
	List<Entry<List<String>,Integer>> entries =
	    new ArrayList<Entry<List<String>,Integer>>();

	String seqcounts = FileUtil.readFile("seqcount.out");
	String[] lines = seqcounts.split("\\n");
	for(String line : lines) {
	    String seq = line.substring(0, line.indexOf(']') + 1);
	    List<String> seqL = FileUtil.parseList(seq);
	    String count = line.substring(line.indexOf(':') + 2);
	    entries.add(new MREntry<List<String>,Integer>(
			    seqL, Integer.parseInt(count)));
	}
	
       	Map<String,List<String>> result = mr.mapReduce(entries);
	FileUtil.writeFile("mostcommonseq.out", result);
    }
}
