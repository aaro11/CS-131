import java.util.*;

import static java.util.Map.Entry;

public class RandomPhrase {

    public static String genPhrase(Map<String,List<String>> mostcommon,
				     String word, int numSeqs) {
	throw new RuntimeException("RandomPhrases.genPhrase not implemented");
    }

    public static void main(String[] args) {
	String mostcommon = FileUtil.readFile("mostcommonseq.out");
	String[] lines = mostcommon.split("\\n");
	Map<String,List<String>> entries =
	    new TreeMap<String,List<String>>();
	for(String line : lines) {
	    int colon = line.indexOf(':');
	    String first = line.substring(0, colon - 1);
	    String seq = line.substring(colon + 2);
	    List<String> seqL = FileUtil.parseList(seq);
	    entries.put(first, seqL);	      
	}
	
       	String word = args[0];
	int numSeqs = Integer.parseInt(args[1]);
	System.out.println(genPhrase(entries, word, numSeqs));
    }
}
